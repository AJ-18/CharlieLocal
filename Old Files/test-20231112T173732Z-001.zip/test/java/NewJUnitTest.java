import org.junit.Test;

public class NewJUnitTest {
    @Test
    public void test( ) {
        assert(true);
    }
}
